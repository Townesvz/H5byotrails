export default {
  resolve: {
    alias: {
      '/data': '/data'
    }
  }
}
